import 'package:flutter/material.dart';
import 'package:todo_list/done_column.dart';
import 'package:todo_list/todo_column.dart';
import 'package:todo_list/top_page.dart';
import 'package:todo_list/utils/device_utils.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.white,
      body: Padding(
        padding: const EdgeInsets.only(top: 28.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const TopPage(title: "MY TODO LIST"),
              SizedBox(
                height: DeviceUtils.getScaledHeight(context, 0.1),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ToDoColumn(),
                  SizedBox(
                    width: DeviceUtils.getScaledWidth(context, 0.05),
                  ),
                  const DoneColumn(),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
