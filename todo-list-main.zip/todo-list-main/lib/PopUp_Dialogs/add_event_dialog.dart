import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/models/event_model.dart';
import 'package:todo_list/models/task_model.dart';
import 'package:todo_list/utils/device_utils.dart';

import '../provider/event_provider.dart';

class AddEventDialog extends StatelessWidget {
  // I want the button text to change according to the action and string.
  // $ options: Add event, Edit event, Add task, Edit task.

  final bool isEventScreen;

  const AddEventDialog({super.key, this.isEventScreen = false});
  @override
  Widget build(BuildContext context) {
    TextEditingController titleController = TextEditingController();
    TextEditingController descriptionController = TextEditingController();

    EventProvider eventProvider =
        Provider.of<EventProvider>(context, listen: false);
    return AlertDialog(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(
            20.0,
          ),
        ),
      ),
      contentPadding: const EdgeInsets.only(
        top: 10.0,
      ),
      title: Center(
        child: Text(
          isEventScreen ? "New Task" : 'New Event',
          style: TextStyle(
            fontSize: 14,
            color: const Color(0xffFFA500),
          ),
        ),
      ),
      content: SizedBox(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  autofocus: true,
                  controller: titleController,
                  decoration: InputDecoration(
                    enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 1,
                        color: Color(0xff389FD6),
                      ),
                    ),
                    // hintText: 'Enter name here',
                    labelText: isEventScreen ? "Task Name" : 'Event Name',
                    labelStyle: const TextStyle(
                      color: Color(0xffFF4D4D),
                    ),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 1,
                        color: Color(0xff389FD6),
                      ),
                    ),
                    // hintText: 'Enter comment here',
                    labelText: 'Description',
                    labelStyle: TextStyle(
                      color: Color(0xffFF4D4D),
                    ),
                  ),
                ),
              ),
              Center(
                child: Container(
                  // width: DeviceUtils.getScaledWidth(context, 0.05),
                  // height: DeviceUtils.getScaledHeight(context, 0.05),
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      if (isEventScreen) {
                        eventProvider.addNewTask(
                          TaskModel(
                            title: titleController.text,
                            description: descriptionController.text,
                          ),
                        );
                      } else {
                        eventProvider.addNewEvent(
                          EventModel(
                            title: titleController.text,
                            description: descriptionController.text,
                            tasks: [],
                            isDone: false,
                          ),
                        );
                      }
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xffFFA500),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "Save",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
