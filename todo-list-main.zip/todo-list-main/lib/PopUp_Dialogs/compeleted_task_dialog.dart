import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:todo_list/utils/assets.dart';

import '../utils/device_utils.dart';

class CompletedDialog extends StatelessWidget {
  const CompletedDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(
            20.0,
          ),
        ),
      ),
      contentPadding: const EdgeInsets.only(
        top: 10.0,
      ),
      title: Center(
        child: Text(
          "Great job for finishing the task!",
          style: TextStyle(
            fontSize: DeviceUtils.getScaledFontSize(context, 10),
            color: const Color(0xff74C69D),
          ),
        ),
      ),
      content: SizedBox(
        height: 200,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text(
              "Only NUMBER tasks more to go :)",
              style: TextStyle(
                color: Color(0xff74C69D),
              ),
            ),
            SvgPicture.asset(
              Assets.clapping,
              width: 27.5,
              height: 30,
              color: const Color(0xff74C69D),
            ),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                primary: const Color(0xff74C69D),
                side: const BorderSide(
                  color: Color(0xff74C69D),
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                "Close",
                style: TextStyle(
                  fontSize: DeviceUtils.getScaledFontSize(context, 8),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
