import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/models/event_model.dart';
import 'package:todo_list/models/task_model.dart';

import '../provider/event_provider.dart';
import '../utils/device_utils.dart';

class DeleteDialog extends StatelessWidget {
  final EventModel event;
  final TaskModel? task;
  const DeleteDialog({super.key, required this.event, this.task});

  @override
  Widget build(BuildContext context) {
    EventProvider eventProvider =
        Provider.of<EventProvider>(context, listen: false);
    return AlertDialog(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(
            20.0,
          ),
        ),
      ),
      contentPadding: const EdgeInsets.only(
        top: 10.0,
      ),
      title: const Center(
        child: Text(
          "Are you sure you want to delete ?",
          style: TextStyle(fontSize: 24.0, color: Color(0xffFF4D4D)),
        ),
      ),
      content: SizedBox(
        height: 75,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                primary: const Color(0xffFF4D4D),
                side: const BorderSide(
                  color: Color(0xffFF4D4D),
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                "No, go back",
                style: TextStyle(
                  fontSize: DeviceUtils.getScaledFontSize(context, 8),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: const Color(0xffFF4D4D),
                elevation: 0,
              ),
              onPressed: () {
                if (task != null) {
                  eventProvider.deleteTask(task!);
                } else {
                  eventProvider.deleteEvent(event);
                }
                Navigator.of(context).pop();
              },
              child: Text(
                "Yes, delete",
                style: TextStyle(
                  fontSize: DeviceUtils.getScaledFontSize(context, 8),
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
