import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/models/event_model.dart';
import 'package:todo_list/models/task_model.dart';
import 'package:todo_list/utils/device_utils.dart';

import '../provider/event_provider.dart';

class EditEventDialog extends StatefulWidget {
  // I want the button text to change according to the action and string.
  // $ options: Add event, Edit event, Add task, Edit task.
  final EventModel event;
  final TaskModel? task;

  const EditEventDialog({super.key, required this.event, this.task});

  @override
  State<EditEventDialog> createState() => _EditEventDialogState();
}

class _EditEventDialogState extends State<EditEventDialog> {
  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.task != null) {
      titleController.text = widget.task!.title;
      descriptionController.text = widget.task!.description;
    } else {
      titleController.text = widget.event.title;
      descriptionController.text = widget.event.description;
    }
  }

  @override
  Widget build(BuildContext context) {
    EventProvider eventProvider =
        Provider.of<EventProvider>(context, listen: false);
    return AlertDialog(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(
            20.0,
          ),
        ),
      ),
      contentPadding: const EdgeInsets.only(
        top: 10.0,
      ),
      title: Center(
        child: Text(
          widget.task != null ? "Edit Task" : 'Edit Event',
          style: const TextStyle(
            fontSize: 14,
            color: Color(0xffFFA500),
          ),
        ),
      ),
      content: SizedBox(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Container(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: titleController,
                  decoration: InputDecoration(
                    enabledBorder: const OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 1,
                        color: Color(0xff389FD6),
                      ),
                    ),
                    // hintText: 'Enter name here',
                    labelText: widget.task != null ? 'Task Name' : 'Event Name',
                    labelStyle: const TextStyle(
                      color: Color(0xffFF4D4D),
                    ),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        width: 1,
                        color: Color(0xff389FD6),
                      ),
                    ),
                    // hintText: 'Enter comment here',
                    labelText: 'Description',
                    labelStyle: TextStyle(
                      color: Color(0xffFF4D4D),
                    ),
                  ),
                ),
              ),
              Center(
                child: Container(
                  padding: const EdgeInsets.all(8.0),
                  child: ElevatedButton(
                    onPressed: () {
                      if (widget.task != null) {
                        eventProvider.updateTask(
                            TaskModel(
                                title: titleController.text,
                                description: descriptionController.text),
                            eventProvider.getTaskIndex(widget.task!));
                      } else {
                        eventProvider.updateEvent(
                          EventModel(
                            title: titleController.text,
                            description: descriptionController.text,
                            tasks: widget.event.tasks,
                            isDone: widget.event.isDone,
                          ),
                          eventProvider.getEventIndex(widget.event),
                        );
                      }
                      Navigator.of(context).pop();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xffFFA500),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.all(8.0),
                      child: Text(
                        "Save",
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
