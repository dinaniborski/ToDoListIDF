import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/event_tile.dart';
import 'package:todo_list/provider/event_provider.dart';
import 'package:todo_list/utils/device_utils.dart';

class DoneColumn extends StatefulWidget {
  final bool isEventScreen;

  const DoneColumn({super.key, this.isEventScreen = false});

  @override
  State<DoneColumn> createState() => _DoneColumnState();
}

class _DoneColumnState extends State<DoneColumn> {
  @override
  Widget build(BuildContext context) {
    EventProvider eventProvider =
        Provider.of<EventProvider>(context, listen: true);
    return SizedBox(
      width: DeviceUtils.getScaledWidth(context, 0.3),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
              "Done",
              style: TextStyle(
                color: Color(0xff389FD6),
                fontSize: DeviceUtils.getScaledFontSize(context, 12),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          widget.isEventScreen
              ? ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) => eventProvider
                              .currentSelectedEvent!.tasks[index].isCompleted ==
                          true
                      ? EventTile(
                          event: eventProvider.currentSelectedEvent!,
                          task:
                              eventProvider.currentSelectedEvent!.tasks[index],
                        )
                      : const SizedBox.shrink(),
                  itemCount: eventProvider.currentSelectedEvent!.tasks.length,
                )
              : ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) =>
                      eventProvider.events[index].isDone == true
                          ? EventTile(
                              event: eventProvider.events[index],
                            )
                          : const SizedBox.shrink(),
                  itemCount: eventProvider.events.length,
                )
        ],
      ),
    );
  }
}
