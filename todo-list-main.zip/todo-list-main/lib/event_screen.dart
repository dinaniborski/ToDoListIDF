import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/done_column.dart';
import 'package:todo_list/models/event_model.dart';
import 'package:todo_list/provider/event_provider.dart';
import 'package:todo_list/todo_column.dart';
import 'package:todo_list/top_page.dart';
import 'package:todo_list/utils/device_utils.dart';

class EventScreen extends StatefulWidget {
  final EventModel event;
  const EventScreen({
    super.key,
    required this.event,
  });

  @override
  State<EventScreen> createState() => _EventScreenState();
}

class _EventScreenState extends State<EventScreen> {
  late EventProvider eventProvider;
  @override
  void initState() {
    super.initState();
    eventProvider = Provider.of<EventProvider>(context, listen: false);
    eventProvider.currentSelectedEvent = widget.event;
  }

  @override
  void dispose() {
    super.dispose();
    eventProvider.currentSelectedEvent = null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:  Colors.white,
      body: Padding(
        padding: const EdgeInsets.only(top: 28.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            TopPage(title: widget.event.title),
            SizedBox(
              height: DeviceUtils.getScaledHeight(context, 0.1),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const ToDoColumn(isEventScreen: true),
                SizedBox(
                  width: DeviceUtils.getScaledWidth(context, 0.05),
                ),
                const DoneColumn(isEventScreen: true),
              ],
            )
          ],
        ),
      ),
    );
  }
}
