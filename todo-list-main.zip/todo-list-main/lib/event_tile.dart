import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/PopUp_Dialogs/delete_dialog.dart';
import 'package:todo_list/PopUp_Dialogs/edit_event_dialog.dart';
import 'package:todo_list/event_screen.dart';
import 'package:todo_list/models/event_model.dart';
import 'package:todo_list/models/task_model.dart';
import 'package:todo_list/provider/event_provider.dart';
import 'package:todo_list/utils/assets.dart';
import 'package:todo_list/utils/device_utils.dart';

class EventTile extends StatelessWidget {
  final EventModel event;
  final TaskModel? task;
  const EventTile({super.key, required this.event, this.task});

  @override
  Widget build(BuildContext context) {
    EventProvider eventProvider =
        Provider.of<EventProvider>(context, listen: false);
    return InkWell(
      onTap: () {
        if (eventProvider.currentSelectedEvent != null) {
        } else {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EventScreen(
                event: event,
              ),
            ),
          );
        }
      },
      child: Padding(
        padding: const EdgeInsets.all(19.0),
        child: Container(
          // height: DeviceUtils.getScaledHeight(context, 0.18),
          // width: DeviceUtils.getScaledWidth(context, 0.2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: task != null
                ? task!.isCompleted
                    ? const Color(0xffCCCCCC)
                    : const Color(0xff74C69D)
                : event.isDone
                    ? const Color(0xffCCCCCC)
                    : const Color(0xff74C69D),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 30),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Column(
                      children: [
                        Text(
                          task != null ? task!.title : event.title,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: DeviceUtils.getScaledFontSize(context, 8),
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                    SvgPicture.asset(
                      Assets.shortLine,
                      width: DeviceUtils.getScaledWidth(context, 0.15),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(top: 18.0),
                      child: Text(
                        task != null ? task!.description : event.description,
                        style: TextStyle(
                          color: const Color(0xff606060),
                          fontSize: DeviceUtils.getScaledFontSize(context, 12),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    IconButton(
                      icon: Icon(
                        size: DeviceUtils.getScaledSize(context, 0.025),
                        event.isDone || (task != null && task!.isCompleted)
                            ? Icons.undo
                            : Icons.check_box_outline_blank,
                      ),
                      color: Colors.white,
                      onPressed: () => {
                        // isDone = true,
                        if (task != null)
                          {
                            if (task!.isCompleted)
                              {
                                eventProvider
                                    .undoTask(eventProvider.getTaskIndex(task!))
                              }
                            else
                              {
                                eventProvider.markTaskAsDone(
                                    eventProvider.getTaskIndex(task!))
                              }
                          }
                        else
                          {
                            if (event.isDone)
                              {eventProvider.undoEvent(event)}
                            else
                              {eventProvider.markEventAsDone(event)}
                          }
                      },
                    ),
                    event.isDone || (task != null && task!.isCompleted)
                        ? const SizedBox.shrink()
                        : IconButton(
                            icon: Icon(
                              Icons.edit_outlined,
                              size: DeviceUtils.getScaledSize(context, 0.025),
                            ),
                            color: const Color(0xffFFA500),
                            onPressed: () => showDialog(
                              context: context,
                              builder: (context) => EditEventDialog(
                                event: event,
                                task: task,
                              ),
                            ),
                          ),
                    event.isDone || (task != null && task!.isCompleted)
                        ? const SizedBox.shrink()
                        : IconButton(
                            icon: Icon(
                              Icons.delete_outline_rounded,
                              size: DeviceUtils.getScaledSize(context, 0.025),
                            ),
                            color: const Color(0xffFF4D4D),
                            onPressed: () => showDialog(
                              context: context,
                              builder: (context) => DeleteDialog(
                                event: event,
                                task: task,
                              ),
                            ),
                          ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
