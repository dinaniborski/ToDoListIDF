import 'package:todo_list/models/task_model.dart';

class EventModel {
  final String title;
  final String description;
  final List<TaskModel> tasks;
  bool isDone;

  EventModel({
    required this.title,
    required this.description,
    required this.tasks,
    required this.isDone,
  });
}
