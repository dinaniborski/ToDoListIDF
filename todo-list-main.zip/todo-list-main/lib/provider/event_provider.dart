import 'package:flutter/material.dart';
import 'package:todo_list/models/task_model.dart';

import '../models/event_model.dart';

class EventProvider with ChangeNotifier {
  List<EventModel> events = [];
  EventModel? currentSelectedEvent;
  void addNewEvent(EventModel event) {
    events.add(event);
    notifyListeners();
  }

  void deleteEvent(EventModel event) {
    events.removeWhere((element) => element == event);
    notifyListeners();
  }

  int getEventIndex(EventModel event) {
    return events.indexWhere((element) => element == event);
  }

  void updateEvent(EventModel event, int index) {
    events[index] = event;
    notifyListeners();
  }

  void markEventAsDone(EventModel event) {
    event.isDone = true;
    notifyListeners();
  }

   void undoEvent(EventModel event) {
    event.isDone = false;
    notifyListeners();
  }

  //----------------------TASKS---------------------------------
  void addNewTask(TaskModel task) {
    currentSelectedEvent!.tasks.add(task);
    notifyListeners();
  }

  void deleteTask(TaskModel task) {
    currentSelectedEvent!.tasks.removeWhere((element) => element == task);
    notifyListeners();
  }

  int getTaskIndex(TaskModel task) {
    return currentSelectedEvent!.tasks.indexWhere((element) => element == task);
  }

  void updateTask(TaskModel task, int index) {
    currentSelectedEvent!.tasks[index] = task;
    notifyListeners();
  }

  void markTaskAsDone(int index) {
    currentSelectedEvent!.tasks[index].isCompleted = true;
    notifyListeners();
  }
   void undoTask(int index) {
    currentSelectedEvent!.tasks[index].isCompleted = false;
    notifyListeners();
  }
}
