import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:todo_list/event_tile.dart';
import 'package:todo_list/provider/event_provider.dart';
import 'package:todo_list/utils/device_utils.dart';

import 'PopUp_Dialogs/add_event_dialog.dart';

class ToDoColumn extends StatefulWidget {
  final bool isEventScreen;
  const ToDoColumn({super.key, this.isEventScreen = false});

  @override
  State<ToDoColumn> createState() => _ToDoColumnState();
}

class _ToDoColumnState extends State<ToDoColumn> {
  @override
  Widget build(BuildContext context) {
    EventProvider eventProvider =
        Provider.of<EventProvider>(context, listen: true);

    return SizedBox(
      width: DeviceUtils.getScaledWidth(context, 0.3),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Text(
                  "To Do",
                  style: TextStyle(
                    color: const Color(0xff389FD6),
                    fontSize: DeviceUtils.getScaledFontSize(context, 12),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      backgroundColor: const Color(0xffFFA500),
                      side: const BorderSide(
                        color: Color(0xffFFA500),
                      ),
                    ),
                    onPressed: () {
                      // showDataAlert(
                      //   context: context,
                      //   title: "Create ID",
                      // );
                      showDialog(
                        context: context,
                        builder: (context) => AddEventDialog(
                          isEventScreen: widget.isEventScreen,
                        ),
                      );
                    },
                    child: const Icon(
                      Icons.add,
                      color: Colors.white,
                    )
                    //  Text(
                    //   widget.isEventScreen ? "Add Task" : "Add Event",
                    //   style: const TextStyle(
                    //     color: Color(0xffFFA500),
                    //   ),
                    // ),
                    ),
              ],
            ),
          ),
          widget.isEventScreen
              ? ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) => eventProvider
                              .currentSelectedEvent!.tasks[index].isCompleted ==
                          false
                      ? EventTile(
                          event: eventProvider.currentSelectedEvent!,
                          task:
                              eventProvider.currentSelectedEvent!.tasks[index],
                        )
                      : const SizedBox.shrink(),
                  itemCount: eventProvider.currentSelectedEvent!.tasks.length,
                )
              : ListView.builder(
                  shrinkWrap: true,
                  itemBuilder: (context, index) =>
                      eventProvider.events[index].isDone == false
                          ? EventTile(
                              event: eventProvider.events[index],
                            )
                          : const SizedBox.shrink(),
                  itemCount: eventProvider.events.length,
                )
        ],
      ),
    );
  }
}
