import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:todo_list/utils/assets.dart';
import 'package:todo_list/utils/device_utils.dart';

class TopPage extends StatelessWidget {
  // The title is a variable so that it changes into an Event name when clicking on a specific event.
  // For example instead of MY TODO LIST it will say : HOST DINNER
  final String title;
  const TopPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Navigator.of(context).canPop()
            ? Padding(
                padding: const EdgeInsets.only(left: 38.0),
                child: IconButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    icon: const Icon(Icons.arrow_back)),
              )
            : const SizedBox.shrink(),
        Expanded(
          child: Column(
            children: [
              Center(
                child: Text(
                  title,
                  style: TextStyle(
                    color: const Color(0xff389FD6),
                    fontSize: DeviceUtils.getScaledFontSize(context, 20),
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              Center(
                child: SvgPicture.asset(Assets.longLine),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
