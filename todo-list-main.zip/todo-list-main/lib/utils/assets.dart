class Assets {
  static const String _imageBase = 'assets';

  static const String clapping = '$_imageBase/clapping.svg';
  static const String longLine = '$_imageBase/longLine.svg';
  static const String shortLine = '$_imageBase/shortLine.svg';
}
